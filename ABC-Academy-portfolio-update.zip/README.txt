Copy the included src folder into your existing project and replace matching files. Only site.js and PortfolioCard.jsx are included. This does not replace your logo component, theme CSS, video page, dependencies, or Firebase settings.
Save the three supplied screenshots as PNG files in public/portfolio:
abc-academy-home.png
abc-academy-staff.png
abc-academy-faq.png
The exhibit has no external website link until the project URL is confirmed. Each screenshot opens at full size in a new tab.
Run npm run lint and npm run build, then preview /portfolio locally. Do not deploy before reviewing.
