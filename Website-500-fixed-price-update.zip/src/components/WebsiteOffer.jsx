import Button from "./Button";

export default function WebsiteOffer({ className = "" }) {
  return (
    <div className={`rounded-2xl border border-cf-gold/60 bg-cf-surface p-6 sm:p-8 ${className}`}>
      <p className="text-sm font-semibold uppercase tracking-widest text-cf-champagne">New website development</p>
      <h2 className="mt-3 text-3xl font-bold text-white sm:text-4xl">$500 <span className="text-xl text-cf-champagne">fixed price</span></h2>
      <p className="mt-3 max-w-2xl text-cf-gray">A professional website for a one-time $500 price. Ongoing management and maintenance are separate.</p>
      <Button to="/contact" size="lg" className="mt-6">Get My $500 Website</Button>
    </div>
  );
}
