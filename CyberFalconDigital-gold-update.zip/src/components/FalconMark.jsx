import falconMarkSrc from "../assets/falcon-gold.png";

// Display the supplied 1414×2000 artwork through a tight SVG viewport.
// This removes the surrounding canvas from the layout without redrawing,
// recoloring, stretching, or changing the original image file.
const ASPECT_RATIO = 789 / 548;

export default function FalconMark({ size = 40, glow = false, className = "", decorative = false }) {
  return (
    <svg
      viewBox="300 470 860 460"
      width={size}
      height={Math.round(size / ASPECT_RATIO)}
      preserveAspectRatio="xMidYMid meet"
      role={decorative ? undefined : "img"}
      aria-hidden={decorative ? true : undefined}
      aria-label={decorative ? undefined : "CyberFalconDigital"}
      className={className}
      style={{
        width: size,
        flexShrink: 0,
        filter: glow ? "drop-shadow(0 0 22px rgba(212,175,55,0.55)) drop-shadow(0 0 44px rgba(255,215,0,0.25))" : undefined,
      }}
    >
      <image href={falconMarkSrc} width="1414" height="2000" />
    </svg>
  );
}
